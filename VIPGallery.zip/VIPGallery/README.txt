VIP Gallery - असली Android ऐप

APK बनाने के 2 तरीके:

तरीका A (Android Studio, कंप्यूटर पर)
1. Android Studio खोलें > Open > यह VIPGallery फ़ोल्डर चुनें।
2. Gradle sync पूरा होने दें।
3. Build > Build APK(s)। APK मिलेगा: app/build/outputs/apk/debug/app-debug.apk
4. APK फ़ोन में डालकर install करें (Unknown sources की अनुमति दें)।

तरीका B (GitHub, बिना Android Studio)
1. GitHub पर नई repository बनाएँ और इस फ़ोल्डर की सारी फ़ाइलें (.github समेत) upload करें।
2. Actions टैब > Build APK > Run workflow।
3. पूरा होने पर Artifacts में VIPGallery-apk डाउनलोड करें।

पहली बार चलाने पर:
- लॉगिन करें > "अनुमति दें" दबाएँ > फ़ोटो की अनुमति दें: पूरी गैलरी अपने-आप आ जाएगी।
- अगला "अनुमति दें" > सेटिंग में VIP Gallery चुनकर "Display over other apps" चालू करें: VIP फ्लोटिंग बटन दूसरे ऐप्स के ऊपर दिखेगा।
- बटन खींचकर कहीं भी रखें। उस पर दबाने से ऐप खुलता है। नोटिफ़िकेशन में "बंद करें" से बटन बंद होता है।
