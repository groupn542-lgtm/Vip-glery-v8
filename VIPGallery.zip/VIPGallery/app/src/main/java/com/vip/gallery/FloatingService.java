package com.vip.gallery;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

/** Real "Display over other apps" floating VIP button. */
public class FloatingService extends Service {

    static FloatingService inst;
    static boolean appVisible = true;

    WindowManager wm;
    TextView btn;
    WindowManager.LayoutParams lp;
    SharedPreferences prefs;
    int startX, startY;
    float touchX, touchY;
    boolean moved;

    static void setAppVisible(boolean v) {
        appVisible = v;
        final FloatingService s = inst;
        if (s != null && s.btn != null) {
            s.btn.post(() -> s.btn.setVisibility(appVisible ? View.GONE : View.VISIBLE));
        }
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        prefs = getSharedPreferences("vip", MODE_PRIVATE);
        if (i != null && "STOP".equals(i.getAction())) {
            prefs.edit().putBoolean("floating", false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startFg();
        if (btn == null) addButton();
        return START_STICKY;
    }

    private void startFg() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("vip", "VIP Gallery", NotificationManager.IMPORTANCE_LOW));

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, FloatingService.class).setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, "vip")
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentTitle("VIP गैलरी चालू है")
                .setContentText("फ्लोटिंग VIP बटन दूसरे ऐप्स के ऊपर दिख रहा है")
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_delete), "बंद करें", stopPi).build())
                .setOngoing(true)
                .build();
        startForeground(1, n);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void addButton() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        inst = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int sz = dp(56);

        btn = new TextView(this);
        btn.setText("VIP");
        btn.setGravity(Gravity.CENTER);
        btn.setTextColor(0xFF2A1D00);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextSize(15);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFFF2C14E);
        g.setStroke(dp(3), 0xFFFFFFFF);
        btn.setBackground(g);
        btn.setElevation(dp(6));

        lp = new WindowManager.LayoutParams(sz, sz,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("fx", getResources().getDisplayMetrics().widthPixels - sz - dp(8));
        lp.y = prefs.getInt("fy", dp(220));

        btn.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = lp.x;
                    startY = lp.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - touchX, dy = e.getRawY() - touchY;
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                    if (moved) {
                        lp.x = startX + (int) dx;
                        lp.y = startY + (int) dy;
                        wm.updateViewLayout(btn, lp);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (moved) {
                        prefs.edit().putInt("fx", lp.x).putInt("fy", lp.y).apply();
                    } else {
                        Intent i = new Intent(this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                    }
                    return true;
            }
            return false;
        });

        btn.setVisibility(appVisible ? View.GONE : View.VISIBLE);
        wm.addView(btn, lp);
    }

    @Override
    public void onDestroy() {
        if (btn != null && wm != null) {
            try {
                wm.removeView(btn);
            } catch (Exception ignored) {
            }
        }
        btn = null;
        inst = null;
        super.onDestroy();
    }
}
