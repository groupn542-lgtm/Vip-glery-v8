package com.vip.gallery;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    static final String HOST = "appassets.vip";
    static final int REQ_PERM = 11, REQ_FILE = 12, REQ_CAM = 13;

    WebView web;
    ValueCallback<Uri[]> chooserCb;
    Uri camUri;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vip", MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath() == null ? "/" : u.getPath();
                try {
                    if (p.equals("/") || p.equals("/index.html")) {
                        return new WebResourceResponse("text/html", "utf-8", getAssets().open("index.html"));
                    }
                    if (p.equals("/api/photos")) return photos();
                    if (p.startsWith("/media/")) return media(p.substring(7));
                    if (p.startsWith("/thumb/")) return thumb(p.substring(7));
                } catch (Exception ignored) {
                }
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pushState();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    chooserCb = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("https://" + HOST + "/index.html");
    }

    /* ---------- state ---------- */

    boolean hasGallery() {
        String perm = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    String stateJson() {
        return "{\"gallery\":" + hasGallery() + ",\"overlay\":" + Settings.canDrawOverlays(this) + "}";
    }

    void pushState() {
        final String js = "window.onNativeState&&window.onNativeState(" + stateJson() + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    void startFloat() {
        if (!Settings.canDrawOverlays(this)) return;
        prefs.edit().putBoolean("floating", true).apply();
        startForegroundService(new Intent(this, FloatingService.class));
    }

    void doRequestGallery() {
        if (hasGallery()) {
            pushState();
            return;
        }
        String perm = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        boolean asked = prefs.getBoolean("askedGallery", false);
        if (asked && !shouldShowRequestPermissionRationale(perm)) {
            // user chose "don't ask again": send them to the app settings page
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        prefs.edit().putBoolean("askedGallery", true).apply();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM);
        } else {
            requestPermissions(new String[]{perm}, REQ_PERM);
        }
    }

    void doCamera() {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "VIP_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VIPGallery");
            camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            i.setClipData(ClipData.newRawUri("", camUri));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAM);
        } catch (Exception e) {
            camUri = null;
        }
    }

    class Bridge {
        @JavascriptInterface
        public String getState() {
            return stateJson();
        }

        @JavascriptInterface
        public void requestGallery() {
            runOnUiThread(MainActivity.this::doRequestGallery);
        }

        @JavascriptInterface
        public void requestOverlay() {
            runOnUiThread(() -> {
                if (Settings.canDrawOverlays(MainActivity.this)) {
                    startFloat();
                    pushState();
                    return;
                }
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            });
        }

        @JavascriptInterface
        public void startFloating() {
            runOnUiThread(MainActivity.this::startFloat);
        }

        @JavascriptInterface
        public void openCamera() {
            runOnUiThread(MainActivity.this::doCamera);
        }
    }

    /* ---------- gallery served to the page ---------- */

    private WebResourceResponse photos() {
        List<long[]> rows = new ArrayList<>();
        Map<Long, String> names = new HashMap<>();
        try (android.database.Cursor c = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED},
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    long taken = c.getLong(2);
                    long t = taken > 0 ? taken : c.getLong(3) * 1000L;
                    rows.add(new long[]{id, t});
                    names.put(id, c.getString(1));
                }
            }
        } catch (SecurityException e) {
            rows.clear();
        } catch (Exception ignored) {
        }
        Collections.sort(rows, (a, b) -> Long.compare(a[1], b[1]));
        JSONArray arr = new JSONArray();
        try {
            for (long[] r : rows) {
                JSONObject o = new JSONObject();
                o.put("id", r[0]);
                o.put("n", names.get(r[0]));
                o.put("t", r[1]);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        byte[] bytes = arr.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
        WebResourceResponse res = new WebResourceResponse("application/json", "utf-8", new ByteArrayInputStream(bytes));
        res.setResponseHeaders(headers("no-store"));
        return res;
    }

    private Uri imageUri(String id) {
        return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Long.parseLong(id));
    }

    private Map<String, String> headers(String cache) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", cache);
        return h;
    }

    private WebResourceResponse media(String id) throws Exception {
        Uri uri = imageUri(id);
        String mime = getContentResolver().getType(uri);
        if (mime == null) mime = "image/jpeg";
        if (mime.contains("heic") || mime.contains("heif")) {
            // WebView cannot show HEIC: convert to JPEG
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 4096) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bm = BitmapFactory.decodeStream(in, null, o);
            }
            if (bm != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 92, bo);
                bm.recycle();
                WebResourceResponse r = new WebResourceResponse("image/jpeg", null,
                        new ByteArrayInputStream(bo.toByteArray()));
                r.setResponseHeaders(headers("max-age=3600"));
                return r;
            }
        }
        InputStream in = getContentResolver().openInputStream(uri);
        WebResourceResponse r = new WebResourceResponse(mime, null, in);
        r.setResponseHeaders(headers("max-age=3600"));
        return r;
    }

    private WebResourceResponse thumb(String id) throws Exception {
        Bitmap bm = getContentResolver().loadThumbnail(imageUri(id), new Size(320, 320), null);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 82, bo);
        WebResourceResponse r = new WebResourceResponse("image/jpeg", null,
                new ByteArrayInputStream(bo.toByteArray()));
        r.setResponseHeaders(headers("max-age=86400"));
        return r;
    }

    /* ---------- lifecycle / results ---------- */

    @Override
    protected void onStart() {
        super.onStart();
        FloatingService.setAppVisible(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        FloatingService.setAppVisible(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pushState();
        if (Settings.canDrawOverlays(this) && prefs.getBoolean("floating", true)) startFloat();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        pushState();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_FILE) {
            if (chooserCb != null) {
                chooserCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
                chooserCb = null;
            }
        } else if (code == REQ_CAM) {
            if (result != RESULT_OK && camUri != null) {
                try {
                    getContentResolver().delete(camUri, null, null);
                } catch (Exception ignored) {
                }
            }
            camUri = null;
            web.postDelayed(() -> web.evaluateJavascript("window.refreshGallery&&window.refreshGallery()", null), 600);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onBack?window.onBack():false)", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }
}
